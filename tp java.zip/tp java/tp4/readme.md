Rendu TP4_POO:

Author : Mehdi BOUTAB
Author : Othman BOUTAB

Groupe03 L2 informatique
===============================================

Présenation du tp:
==================

* Le Tp contient un seul exercice qui a pour but d'apprendre à écrire une classe, rédiger une documentation, et utiliser une méthodologie rigoureuse basés sur les tests unitaires.

* La documentation:
elle peut être générée à l’aide de l’outil javadoc.
il faut se placer dans le dossier contenant la classe que l'on souhaite complier  nom_classe.java
ensuite exécutez la commande
$ javadoc nom_classe.java -d docs
un dossier docs va se créer sur le répertoire où figure notre travail 
ce dernier contiendra des fichier .html il suffit de les ouvrir sur un navigateur pour consulter la documentation.

* Pour compiler une classe :
il faut se placer dans le dossier où figure cette classe ensuite sur un terminal il faut taper les commandes :
$ javac nom_classe.java


* pour compiler et executer les tests : 
il faut se placer dans le dossier où figure le dossier de nos tests ensuite sur un terminal il faut taper les commandes :
$ javac -classpath .:test-1.7.jar test/BikeTest.java //compiler
ensuite pour executer :
$ java -jar test-1.7.jar BikeTest
avec test-1.7.jar : le dossier contenant les test

* réponse à la question 4 :
  -------------------------
le code du fichier BikeModel.java définit trois models de vélos qui sont : CLASSICAL, ELECTRIC, TANDEM de type enum


* pour récuperer l'ensemble des fichiers du TP4, il faut d'abord se positionner dans le dossier BOUTAB-BOUTABO-poo
ensuite ouvrir un terminal et taper la commade $ git pull


