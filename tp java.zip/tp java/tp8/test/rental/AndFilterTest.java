package rental;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;



public class AndFilterTest {

    @Test
    public void addFilterTest(){
        VehicleFilter criterion = new BrandFilter("brand1");
        VehicleFilter porche= new MaxPriceFilter(100);
        AndFilter des_filtres= new AndFilter();
        des_filtres.addFilter(criterion);
        des_filtres.addFilter(porche);
        Vehicle po= new Vehicle("porche","911",2017,90);
        Vehicle po1= new Vehicle("porche","911",2017,120);
        assertTrue(des_filtres.accept(po));
        assertFalse(des_filtres.accept(po1));

    }
    // ---Pour permettre l'execution des tests ----------------------
    
    public static junit.framework.Test suite() {
        return new junit.framework.JUnit4TestAdapter(rental.ClientTest.class);
        }
}