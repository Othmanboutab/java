package image.color;
public class GrayColor {
	// data fields attributes
	private double alpha  ;
	private int  grayLevel;
	public static final GrayColor WHITE = new GrayColor(255);
	public static final GrayColor BLACK = new GrayColor(0);
	 /**
     * create a new grayColor with the given level, and 1 as alpha level(opacity)
     * @param level gray level of this grayColor
     */
	public GrayColor(int level){
		this.alpha = 1;
		if(level >=0 && level <= 255) 
			this.grayLevel = level;
	}
	  /**
     * return the gray level of this grayColor
     * @return the gray level of this grayColor
     */	
	public int  getGrayLevel() {
		return this.grayLevel;
	}
    /**
     * return the alpha (opacity) level of this grayColor
     * @return the alpha (opacity) level of this grayColor
     */
	public double  getAlpha() {
		return this.alpha;
		
	}
	/**
	 * set a new alpha (opacity) level for this grayColor
	 * @param a
	 */
	public void setAlpha(double a) {
		this.alpha = a;
	}

	/**
	 *
	 * @param o
	 * @return
	 */
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        GrayColor grayColor = (GrayColor) o;
        return grayLevel == grayColor.grayLevel &&
                Double.compare(grayColor.alpha, alpha) == 0;
    }

	
}
