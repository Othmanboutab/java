package rental;
import rental.*;

import java.util.*;

/** a rental vehicle agency, client can rent one vehicle at a time */
public class RentalAgency {
    // vehicles of this agency
    protected List<Vehicle> theVehicles;

    // maps client and rented vehicle (at most one vehicle by client) 
    protected Map<Client,Vehicle> rentedVehicles;

    public RentalAgency() {
        this.rentedVehicles= new HashMap<Client, Vehicle>();
        this.theVehicles= new ArrayList<Vehicle>();
    }
    
    /** adds a vehicle to this agency 
    * @param v the added vehicle
    */
    public void addVehicle(Vehicle v) {
    	this.theVehicles.add(v);
    }

    /** provides the list of the vehicles that is accepted by filter  
    * @param filter the selection filter
    * @return  the list of the vehicles accepted by filter
    */
    public List<Vehicle> select(VehicleFilter filter) {	
        List<Vehicle> res= new ArrayList<Vehicle>();
        for(Vehicle v:this.theVehicles){
            if(filter.accept(v)){
                res.add(v);
            }
        }
        return res;
    }
    
    /** displays the vehicles accepted by the filter 
    * @param filter the selection filter
    */
    public void displaySelection(VehicleFilter filter) {
    	System.out.println(select(filter));
    }


    /** returns <em>true</em> iff client c is renting a vehicle
     * @param client the client for which we want to know it has rented a vehicle
    * @return <em>true</em> iff client c is renting a vehicle
    */
    public boolean hasRentedAVehicle(Client client){
    	return this.rentedVehicles.containsKey(client);

    }
    
    /** returns <em>true</em> iff vehicle v is rented
     * @param v the vehicle we want to check if it is rented
    * @return <em>true</em> iff vehicle v is rented    
    */
    public boolean isRented(Vehicle v){
    	return this.rentedVehicles.containsValue(v);
    }

   /** client rents a vehicle 
    * @param client the renter
    * @param v the rented vehicle
    * @return the daily rental price
    * @exception UnknownVehicleException   if v is not a vehicle of this agency  
    * @exception IllegalStateException if v is already rented or client rents already another vehicle
    */
    public float rentVehicle(Client client, Vehicle v) throws UnknownVehicleException, IllegalStateException {
    	if(isRented(v)){
            throw new IllegalStateException(" la voiture "+v.getModel()+" est déja louée");
        }else if(hasRentedAVehicle(client)){
            throw new IllegalStateException("le client "+client.getName()+" a déja loué une voiture");
        }else if(! this.theVehicles.contains(v)){
            throw new UnknownVehicleException(" la voiture n'existe pas");

        }else{
            this.rentedVehicles.put(client,v);
            return v.getDailyPrice();

        }
    	
    }

    
    /** the client returns a rented vehicle. Nothing happens if client didn't have rented a vehicle. 
    * @param client the client who returns a vehicle
    */
    public void returnVehicle(Client client){
        if(hasRentedAVehicle(client)){
            this.rentedVehicles.remove(client);
        }
    }
    /** provides the collection of rented vehicles for this agency
    * @return collection of currently rented vehicles 
    */
    public Collection<Vehicle> allRentedVehicles(){
    	
        return this.rentedVehicles.values();
    }

    public static void main(String[] args) {
        BrandFilter filtreBrand= new BrandFilter("Porche");
        MaxPriceFilter filtrePrice=new MaxPriceFilter(100);
        AndFilter filtres = new AndFilter();
        filtres.addFilter(filtreBrand); 
        filtres.addFilter(filtrePrice);
        RentalAgency agency = new RentalAgency();
        Vehicle porche = new Vehicle("Porche", "Panamera", 2000, 10);
        Vehicle firrari = new Vehicle("Porche", "911", 2017, 110);
        Vehicle buggati = new Vehicle("Buggati", "Verron", 2018, 180);
        Client Chris =  new Client("Chris",19);
        Client Raoult =  new Client("Raoult",81);

        agency.addVehicle(porche);
        agency.addVehicle(firrari);
        agency.addVehicle(buggati);
        
        agency.displaySelection(filtres);
        try{
            agency.rentVehicle(Raoult,buggati);
            
            agency.rentVehicle(Raoult,firrari);
        }catch (UnknownVehicleException e){
            System.out.println(e.getMessage());
        }
    }

}
