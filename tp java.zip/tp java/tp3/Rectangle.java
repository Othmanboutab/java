/**
 * A class that creating rectangle with largeur & longueur;
 * @author Mehdi BOUTAB
 * @author Othman BOUTAB
 * @version 5/10/2020
 */
package com.company;

public class Rectangle {
    // DEFINIR LES ATTRIBIUTS
        private double longueur;
        private double largeur;

    /**
     * create a rectangle with given largeur & longueur;
     * @param longueur
     * @param largeur
     */
        public Rectangle(double longueur, double largeur) {
            this.longueur = longueur;
            this.largeur = largeur;
        }

    /**
     * return the longeur of this rectangle;
     * @return the longueur;
     */
        public double getLongueur() {
            return this.longueur;
        }

    /**
     * return the longueur of this rectangle;
     * @param longueur
     */
    public void setLongueur(double longueur) {
            this.longueur = longueur;
        }

    /**
     * return rectangle's largeur;
     * @return the largeur;
     */
    public double getLargeur() {
            return this.largeur;
        }

    /**
     * return rectangle's largeur
     * @param largeur
     */
    public void setLargeur(double largeur) {
            this.largeur = largeur;
        }

    /**
     * return perimetre of this rectangle;
     * @return perimetre of this rectangle;
     */
    public double perimetre() {
            return (this.longueur + this.largeur) * 2;
        }

    /**
     * return aire of this rectangle;
     * @return aire of this rectangle;
     */
    public double aire() {
            return longueur * largeur;
        }

    /**
     * return true if this rectangle is caree;
     * @return true if this rectangle is carre
     *          false otherwise
     */
    public boolean isCarre() {
            if (longueur == largeur)
                return true;
            else
                return false;
        }

    /**
     * return a string represetation of this rectangle:
     * @return a string represatation of this rectangle using format
     *         longueur + largeur + permtre + aire + si c'est un carré ou non;
     */
    public String toString() {
            String etat = null;
            if (this.isCarre())
                etat = "C'est un carré";
            else
                etat = "Ce n'est pas un carré";

            return "-Longueur : " + this.longueur + " -Largeur : " + this.largeur
                    + " -Perimetre : " + this.perimetre() + " -Aire : "
                    + this.aire() + " -" + etat;
        }

    /**
     * return if this rectangle equal to other;
     * @param other
     * @return true if this rectangle equals other;
     *         false otherwise
     */
    public boolean equals(Rectangle other) {
        if (other == null) return false;
        if (other == this) return true;
        if (!(other instanceof Rectangle)) return false;
        return this.largeur == ((Rectangle) other).largeur;
    }
}
