/**
 * A class to design bike station
 * @author Mehdi BOUTAB
 * @author Othman BOUTAB
 *
 */
public class BikeStation {

	/**
	 * array of slots for bikes in the station
	 */
	private Bike[] Bikes;
	/**
	 * name of the station
	 */
	private String name;
	/**
	 * number of bikes in the station
	 */
	private int numberOfBikes;
	/**
	 * capacity in the station
	 */
	private int capacity;

	/**
	 * create a BikeStation with given a name and capacity
	 *
	 * @param name     this bike's name
	 * @param capacity this bike's capacity
	 */
	public BikeStation(String name, int capacity) {
		this.capacity = capacity;
		this.name = name;
		this.numberOfBikes = 0;
		this.Bikes = new Bike[this.capacity];
	}

	/**
	 * return this bike's name
	 *
	 * @return the name of this BikeStation
	 */
	public String getName() {
		return this.name;
	}

	/**
	 * return this bike's capacity
	 *
	 * @return the capacity of this BikeStation
	 */
	public int getCapacity() {
		return this.capacity;
	}

	/**
	 * return the number of bikes
	 *
	 * @return the number of bikes
	 */
	public int getNumberOfBikes() {
		return this.numberOfBikes;
	}

	/**
	 * return the number of Free Slot in the Bike's station if there is no free slot return -1
	 *
	 * @return the number of Free Slot
	 */
	public int firstFreeSlot() {
		for (int i = 0; i < this.Bikes.length; i++)
			if (this.Bikes[i] == null) {
				return i;
			}
		return -1;
	}

	/**
	 *
	 * return <code> True </code> if the bike was possible to deposit otherwise <code>False</code>
	 * @param bike;
	 * @return <code>True</code> or <code>False</code>
	 */
	public boolean dropBike(Bike bike) {
		int index = this.firstFreeSlot();
		if (index != -1) {
			Bikes[index] = bike;
			numberOfBikes = numberOfBikes + 1;
			return true;
		} else {
			return false;
		}
	}

	/**
	 * return velo or if there ni no bike at the requested location return null
	 * @param i;
	 * @return velo if there's velo in station , otherwise null
	 */
	public Bike takeBike(int i) {
		if (i >= 0 && i < this.capacity && Bikes[i] != null) {
			Bike velo = Bikes[i];
			Bikes[i] = null;
			numberOfBikes = numberOfBikes - 1;
			return velo;
		}
		return null;
	}

	public String toString() {
		return "la station " + this.name + "de capacité " + this.capacity;
	}
}

