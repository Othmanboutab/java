package date;
import date.*;

public class DateMain {

 public static void main(String[] args) {
   Date d1 = new Date(14, Month.Octobre, 2020);
   Date d2 = new Date(13, Month.Octobre, 2020);
   Date d3 = new Date(16, Month.Octobre, 2020);

   System.out.println(d1.getDay() + " is the day of date " + d1.toString());
   System.out.println(d1.getMonth() + " is the month of date " + d1.toString());
   System.out.println(d1.getYear() + " is the year of date " + d1.toString());

   System.out.println(d1.tomorrow().toString() + " is the day after the date" + d1.toString());

   System.out.println(d1.toString() + " belongs to a leap year? : " + d1.isBissextile(d1.getYear()));

   System.out.println(d1.nDaysLater(15) + " is the 15 th day after " + d1.toString());

   System.out.println(d2.diffDay(d1) + " day separate " + d2.toString() + " of " + d1.toString());
   System.out.println(d1.diffDay(d3) + " day separate " + d1.toString() + " of " + d3.toString());

 }

}
