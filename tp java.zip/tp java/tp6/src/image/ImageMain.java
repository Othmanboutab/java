package image;
import image.util.*;
public class ImageMain {
	public static void main(String[] args) {
		String fileName = "/images/lamp.pgm";
		int threshold = 20;
		int nbGrayLevels = 8;

		if (args.length >= 1) {
			fileName = args[0];
		}
		if (args.length >= 2) {
			threshold = Integer.parseInt(args[1]);
		}
		if (args.length == 3) {
			nbGrayLevels = Integer.parseInt(args[2]);
		}

		Image I = Image.initImagePGM(fileName);
		ImageDisplayer ID = new ImageDisplayer();
		ID.display(I,"Image");
		ID.display(I.edges(threshold),"Image",100+I.getWidth(),100);
		ID.display(I.decreaseNbGrayLevels(nbGrayLevels),"Image",100+I.getWidth()*2,100);

	
	
	}
	

}
