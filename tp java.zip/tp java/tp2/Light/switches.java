/**
 * Décrivez votre classe Switch ici.
 *
 * @author Mehdi BOUTAB
 * @version 29/09/2020
 */
public class Switch
{
    // variables d'instance - remplacez l'exemple qui suit par le vôtre
    private Lightbulb Light;

    /**
     * There is a swicth that control a lightbulb named Light
     */
    public Switch(Lightbulb L)
    {
        // initialisation des variables d'instance
       this.Light=L;
    }

    /**
     return a string that represent the state of the lightbulb
     @return a string that represent the state of the lightbulb
     */
    public String getState()
    {
        // Insérez votre code ici
        return this.Light.getState();
    }
        /** change the state of the lightbulb connected to the switch
           @param s a string "on" or something else*/
    public void setState(String s)
    {
        this.Light.setState(s);
    }
}
