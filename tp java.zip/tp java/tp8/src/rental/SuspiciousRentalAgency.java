package rental;
import rental.*;

import java.util.*;

public class SuspiciousRentalAgency extends RentalAgency{


    public SuspiciousRentalAgency(){
        super(); // on peut ne pas le mettre
    }
    /** client rents a vehicle 
    * @param client the renter
    * @param v the rented vehicle
    * @return the daily rental price
    * @exception UnknownVehicleException   if v is not a vehicle of this agency  
    * @exception IllegalStateException if v is already rented or client rents already another vehicle
    */

    public float rentVehicle(Client client, Vehicle v){
        float res=0;
        try{
            if (client.getAge()>25){
                res=super.rentVehicle(client, v);
            }else{
                res=super.rentVehicle(client, v)+(v.getDailyPrice()/10);
            }
        }catch(UnknownVehicleException e){
            System.out.println("voiture existe pas");
            
        }
        return res;
       
       
    }


}