package image;

public class UnknownPixelException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UnknownPixelException() {}
	
	public UnknownPixelException(String msg) {
		super(msg);
	}
}
