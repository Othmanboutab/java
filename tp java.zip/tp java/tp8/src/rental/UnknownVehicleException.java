package rental;
import java.util.*;
public class UnknownVehicleException extends Exception{
  public UnknownVehicleException(String msg){
    super(msg);
}
}
