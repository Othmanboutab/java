/**
 * Write a description of class Lightbulb here.
 *
 * @author Mehdi BOUTAB
 * @version 29/09/2020
 */
public class Lightbulb
{
   /** This lightbulb's state */
   private boolean state;
   /** This lightbulb's color */
   private String color;
   /** This lightbulb's power */
   private int power;
   
   /** A lightbulb is defined by its color and its power*/
   public Lightbulb(String color, int power)
    {
        this.color=color;
        this.power=power;
        this.state=false;
    }
   /** returns the lightbulb's power 
    *  @return the lightbulb's power 
    */
   public int getPower()
    {
        return this.power;
    }
   /** returns the lightbulb's color 
    *  @return the lightbulb's color 
    */
   public String getColor()
    {
       return this.color;
    }
   /** returns the lightbulb's state 
    *  @return the lightbulb's state 
    */
   public String getState()
   {
       if (this.state==false)
        {
           return "off";
        }
       else
        {
           return "on";
        }
   }    
   /** sets the lightbulb's state 
      @param s string "on" or something else*/
   public void setState(String s)
   {
       if (s=="on")
       {
           this.state=true;
        }
       else
       {
           this.state=false;
        }
    }
   /** returns a string representation of the lightbulb
    * @return a string representation of the lightbulb
    */
   public String toString()
   {
       return "the lightbulb is "+this.getState()+", its color is "+this.color+" and its power is "+this.power+" W";
   }
}

