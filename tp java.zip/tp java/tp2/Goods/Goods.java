
/** This class represents a Goods characterized by its value and name
 * @author Mehdi BOUTAB
 * @version 29/09/2020
 */

public class Goods{

  //ATTRIBUTS
  private double value;
  private String name;

  //Constructeurs
  /** create a  Goods with initial value = 0
  *@param name the initial name of this Goods
  */
  public Goods(String name){
    this.name = name;
    this.value = 0;
  }
  /** creates a  Goods with value and a name given
  *@param name the initial name of this Goods
  *@param name the initial value of this Goods
  */
  public Goods(String name,double value){
    this.name = name;
    this.value = value;
  }
  //METHODES
  //getters
  /** gives the value of this Goods
   * @return the value of this Goods
   */
   public double getValue(){
     return this.value;
   }
   /** gives the name of this Goods
    * @return the name of this Goods
    */
    public String getname(){
      return this.name;
    }
    //setters
    /** set the value of this Goods
     */
     public void setValue(double value){
       this.value = value;
     }
     /** set the name of this Goods
      */
      public void setName(String name){
        this.name = name;
      }
      /** calculate the TVA of goods for 20%
       */
       public double calculateTVA(){
         double tva;
         tva = this.value/1.2;
         return tva;
       }
      /**
      *provide a string representation for this Goods object
    	*/
      public String toString(){
        return "the goods name is "+this.name+" and the goods value is "+this.value;
      }

}
