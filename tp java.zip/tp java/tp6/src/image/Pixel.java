package image;
import java.lang.Math;
import image.color.GrayColor;
public class Pixel {
	// Attributes of the class
		private GrayColor color ;
		   /**
	     * create a Pixel with the given color
	     * @param c color used to create this pixel
	     */
		public Pixel(GrayColor c) {
			this.color = c;
			
		}
		   /**
	     * return the color of this pixel
	     * @return
	     */
	  
		public GrayColor getColor() {
			return this.color;
		}
		  /**
	     * set a new color for this pixel
	     * @param c1 the new color for this pixel
	     */
		
	
		public void setColor(GrayColor c1) {
			this.color = c1;
		}
		/* return 's true of two objects have same color or  false instead
		 * @param Object p
		 * @return true only if this color and "o" are equivalent
		 * 
		 */
		public boolean equals(Object p) {
			if(p instanceof Pixel) {
				Pixel pixel =(Pixel)p;
				return pixel.color.equals(this.color);
						
			}
			else
				return false;
			
		}
		  /**
	     * return an positive integer, representing the difference between
	     * this pixel's gray level and the gray level of "that" 
	     * @param that  another pixel
	     * @return return an positive integer, representing the difference between
	     * this pixel's gray level and the gray level of "that"
	     */
	
		public int colorLevelDifference(Pixel that ) {
			return Math.abs(this.color.getGrayLevel() - that.color.getGrayLevel());
		}
	

 
}
