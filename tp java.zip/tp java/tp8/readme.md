# TP5 : Agence de location de voitures

**OTHMAN BOUTAB , MEHDI BOUTAB**



### Le TP

L'objectif de ce TP est d'implémenter le problème du sujet du TD sur les agences de location de voiture étudié en classe.

On veut résoudre un problème de location de véhicules, sachant y a plus types de véhicules qui en héritent d'elle même déja, comme Car et Moto,

De plus on a un type d'agence qui hérite de RentalAgency aussi qui une plus d'options.


### Documentation

.Pour générer la documentation et la retrouver dans le dossier *docs* on réalise la commande à partir du dossier src:

	`javadoc rental -d ../docs`

*Note:* Cette commande se réalise du dossier src

### Compilation

.Pour compiler les classes de ce tp on se met dans le dossier src et on  exécute les commandes suivantes:

    
    ```bash
    javac -d ../classes rental/*.java
  
### Execution 

.Pour executer les classes de ce tp on se met dans le dossier classes et on  exécute les commandes suivantes:
  
    ```bash
    java rental/Main
  

 
### Les Tests

.Pour compiler les classes de tests et exécuter les tests JUnit4 avec une fenêtre graphique, on utilise la commande :

	`javac -classpath test-1.7.jar test/rental/RentalAgencyTest.java`
	
	`javac -classpath test-1.7.jar test/rental/VehicleTest.java`

	`javac -classpath test-1.7.jar test/rental/ClientTest.java`

	`javac -classpath test-1.7.jar test/rental/AndFilterTest.java`
	
	`javac -classpath test-1.7.jar test/rental/BrandFilterTest.java`

	`javac -classpath test-1.7.jar test/rental/MaxPriceFilterTest.java`
	

### Execution des tests

	java -jar test-1.7.jar rental.RentalAgencyTest
	
	`java -jar test-1.7.jar rental.VehicleTest

	`java -jar test-1.7.jar rental.ClientTest

	`java -jar test-1.7.jar rental.AndFilterTest
	
	`java -jar test-1.7.jar rental.BrandFilterTest

	`java -jar test-1.7.jar rental.MaxPriceFilterTest
	

### Générer l'archive jar

.on genère l'archive exécutable *jar* du package *rental* avec la commande en ce plaçant dans le dossier classes :

	`jar cvfm ../appli.jar ../manifest-re rental`

.Noter que l'archive contient la documentation et les tests.


### Exécuter le programme

Pour exécuter le programme on génère l'archive jar puis on lance la commande en ce plaçant à la racine du projet:

	`java -jar appli.jar`




