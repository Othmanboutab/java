package rental;
import rental.*;


import java.util.*;
public class Main{


public static void main(String[] args) {
    Motorbike z1000 = new Motorbike("yamaha", "z1000", 2018, 175, 1000);
    Vehicle porche = new Vehicle("Porche", "Panamera", 2000, 180);
    Car firrari = new Car("Porche", "911", 2017, 170, 2);
    Car Mercedes = new Car("Mercedes", "C63", 2020, 150, 5);
    Vehicle Bentelli = new Vehicle("Bentelli", "Panamera", 2013, 130);
    Motorbike gsxr = new Motorbike("suzuki", "gsxr1000", 2018, 130, 1200);

    SuspiciousRentalAgency agence= new SuspiciousRentalAgency();

    agence.addVehicle(z1000);
    agence.addVehicle(porche);
    agence.addVehicle(firrari);
    agence.addVehicle(Mercedes);
    agence.addVehicle(Bentelli);
    agence.addVehicle(gsxr);

    
    MaxPriceFilter filtrePrice=new MaxPriceFilter(160);

    //agence.displaySelection(filtrePrice);

    Client Chris =  new Client("Chris",19);
    Client Raoult =  new Client("Raoult",81);
    Client Rayane= new Client("Rayane",27);
    
    System.out.println(Raoult.getName()+" Age "+Raoult.getAge()+" ans a loué la moto "+z1000.getBrand()+" "+z1000.getModel()+" au prix de "+ agence.rentVehicle(Raoult,z1000)+" €");
    
    System.out.println(Chris.getName()+" Age "+Chris.getAge()+" ans a loué la voiture "+ Mercedes.getBrand() +" "+ Mercedes.getModel()+" au prix de "+ Mercedes.getDailyPrice()+" € plus un surcoût de 10% sur le prix de la location, total: "+ agence.rentVehicle(Chris,Mercedes)+" €");

    System.out.println(Rayane.getName()+" Age "+Rayane.getAge()+" ans a loué la voiture "+porche.getBrand() +" "+ porche.getModel()+" au prix de "+ agence.rentVehicle(Rayane,porche)+" €");


}
}
