package pfc.util;
import pfc.Shape;
/**
 * An interface class to create Strategy to play shifumi game.
 * @author Mehdi BOUTAB && Othman BOUTAB

 */
public interface Strategy{

  /**
    * Obtains the shape to play in function of the strategy which call this interface.
    * @return The shape to play in function of the strategy which call this interface.
    */
  public Shape getShape();
}
