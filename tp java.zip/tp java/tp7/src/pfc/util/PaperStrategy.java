package pfc.util;
import pfc.Shape;
/**
 * A class which represent the strategy which play only PAPER Shape.
 * @author Mehdi BOUTAB && Othman BOUTAB

 */
public class PaperStrategy implements Strategy{

  /**
    * Gives the shape to play with this strategy.
    * @return The Shape to play.
    */
  public Shape getShape(){
    return Shape.PAPER;
  }

}
