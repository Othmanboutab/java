package pfc.util;
import pfc.Shape;
/**
 * A class to use a random Shape as a strategy.
 * @author Mehdi BOUTAB && Othman BOUTAB
 */
public class RandomStrategy implements Strategy{

  /**
    * Gives the shape to play with this strategy.
    * @return The Shape to play.
    */
  public Shape getShape(){
    return Shape.randomShape();
  }

}
