import static org.junit.Assert.*;
import org.junit.Test;
import image.Image;
import image.Pixel;
import image.UnknownPixelException;
import image.color.GrayColor;
public class ImageTest  {
	private static final int WIDTH = 20;
	private static final int HIEGHT =40;
	@Test
	public void testImage() {
		// create an instance of class
		Image im = new Image(ImageTest.WIDTH,ImageTest.HIEGHT);
		assertNotNull(im);
		
	
	}
	  @Test
	  public void testGetWidth(){
	    Image i = new Image(10,20);
	    assertEquals(i.getWidth(),10);
	  }
	  @Test
	  public void testGetHeight(){
	    Image i = new Image(10,20);
	    assertEquals(i.getHeight(),20);
	  }
	  @Test
	  public void testGetPixel(){
	    Image i = new Image(10,20);
	    Pixel p = new Pixel(new GrayColor(16));
	    i.setPixel(5,5,p);
	    assertEquals(i.getPixel(5,5),p);
	  }
	  @Test
	  public void testchangeColorPixel(){
	    Image i = new Image(10,20);
	    assertTrue(i.getPixel(5,5).equals(new Pixel(new GrayColor(255))));
	    i.changeColorPixel(5,5,new GrayColor(64));
	    assertFalse(i.getPixel(5,5).equals(new Pixel(new GrayColor(255))));
	    assertTrue(i.getPixel(5,5).equals(new Pixel(new GrayColor(64))));
	  }
	  
	  /*
	     * check that the weight and height both match the given params at creation 
	     */
	    @Test
		public void returnWidthTest() {
	            Image image = new Image(420, 360);
	            assertEquals(image.getWidth(), 420);
	    }

	    /**
	     * check that height matchs the given params at creation 
	     */
	    @Test
		public void returnHeightTest() {
	            Image image = new Image(420, 360);
	            assertEquals(image.getHeight(), 360);
	    }

	    /**
	     * check that pixels are all white at creation
	     */
	    @Test
		public void returnPixelColorTest() {
	            Image image = new Image(420, 360);      
	            for(int x = 0; x < 420; x++){
	                for( int y = 0; y < 360; y++){
	                    assertEquals(image.getPixel(x, y).getColor(), GrayColor.WHITE);
	                }
	            }
	    }

	    /**
	     * check that fillRectangle fills with white color 
	     */
	    @Test
		public void fillRectangleTest() {
	            Image image = new Image(420, 360);
	            image.fillRect(5, 5, 50, 50, GrayColor.WHITE);
	            for(int x = 5; x < 55; x++){
	                for( int y = 5; y < 55; y++){
	                    assertEquals(image.getPixel(x, y).getColor(), GrayColor.WHITE);
	                }
	            }
	    }

	    /**
	     * check that changeColorPixel method is working
	     */
	    @Test
		public void changeColorPixelTest() {
	            Image image = new Image(420, 360);
	            image.getPixel(0, 0).setColor(GrayColor.BLACK);
	            assertEquals(image.getPixel(0, 0).getColor(), GrayColor.BLACK);
	    }

	 

	  @Test
	  public void TestDecreaseNbGrayLevels(){
	    Image i = new Image(2,2);
	    i.setPixel(0,0,new Pixel(new GrayColor(37)));
	    i.setPixel(0,1,new Pixel(new GrayColor(133)));
	    i.setPixel(1,0,new Pixel(new GrayColor(185)));
	    i.setPixel(1,1,new Pixel(new GrayColor(237)));

	    Image d = i.decreaseNbGrayLevels(4);
	    assertTrue(d.getPixel(0,1).getColor().getGrayLevel() == 128 );
	    assertTrue(d.getPixel(1,0).getColor().getGrayLevel() == 128);
	    assertTrue(d.getPixel(1,1).getColor().getGrayLevel() == 192);
	  }
	  
	
	@Test(expected = UnknownPixelException.class)
	public void  testChangePixelThatNotExists() throws UnknownPixelException {
		Image im= new Image(ImageTest.WIDTH,ImageTest.HIEGHT);
		im.changeColorPixel(ImageTest.WIDTH,ImageTest.HIEGHT, GrayColor.BLACK);
	}
	 @Test

	  public static junit.framework.Test suite() {
	        return new junit.framework.JUnit4TestAdapter(ImageTest.class);
	    }
	

		
			
			
			
		
	
	

	

}

