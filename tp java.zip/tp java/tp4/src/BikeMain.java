public class BikeMain{
  public static void main(String[] args) {
    Bike bike1 = new Bike("b001",BikeModel.CLASSICAL);
    Bike bike2 = new Bike("b002",BikeModel.ELECTRIC);
    if (bike1.equals(bike2) == false) {
			System.out.println("the two bikes are not equal");
                  }
		else{
			System.out.println("the two bikes are equal");

		}
    System.out.println("the description of the first bike is : "+bike1.toString());

  }
}
