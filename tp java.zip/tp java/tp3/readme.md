Rendu TP3_POO:

Les binomes : Mehdi Boutab && Othman Boutab

Groupe03 L2 informatique 

======================================================
objéctifs du tp:
==================

* Savoir coder des classes.
* Apprendre à compiler.
* Ecrire méthode main et savoir les exécuter.

Lien du TP:
==========
https://www.fil.univ-lille1.fr/~routier/enseignement/licence/poo/tdtp/tp3.pdf

exercice 1:
========== 
Dans cet exercice , on va creer une classe Rectangle qui permet de représenter des réctangles , et caractérisé par les valeurs longueur et largeur de types double , on va pouvoir définir les attributs nécessaire pour la classe Rectangle , et on ajoute des méthodes pour calculer l'aire du rectangle et son périmétre , ainsi de déterminer si ce dernier est un carré et teser l'égalité entre deux rectangles.

exercice 2:
==========
dans cet exercice on va creer une classe Complexe qui va nous permetre de créé 2 nombres complexes , et calculer leur conjugés , leur somme et leur produit , sans oublier de savoir tester l'égalité des complexes somme et produit qu'on a obtenue.


 La documentation:
===================
elle peut être générée à l’aide de l’outil javadoc.
il faut se placer dans le dossier contenant la classe que l'on souhaite complier  nom_classe.java
ensuite exécutez la commande
$ javadoc nom_classe.java -d docs
un dossier docs va se créer sur le répertoire où figure notre travail 
ce dernier contiendra des fichier .html il suffit de les ouvrir sur un navigateur pour consulter la documentation.

* Pour compiler une classe :
il faut se placer dans le dossier où figure cette classe ensuite sur un terminal il faut taper les commandes :
$ javac nom_classe.java


