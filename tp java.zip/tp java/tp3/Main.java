package com.company;

public class Main {

    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(2.3 , 4.3);
        Rectangle r2 = new Rectangle(5.5 , 6.3);
        Rectangle r3 = new Rectangle(5.5 , 6.3);

        System.out.println("L'aire de r1 est "+r1.aire());
        System.out.println("L'aire de r2 est "+r2.aire());
        System.out.println("Perimetre de r1 est "+r1.perimetre());
        System.out.println("Perimetre  de r2 est "+r2.perimetre());
        System.out.println("c'est égale "+r1.equals(r3));
        System.out.println("Description de Rectangle :"+r1.toString());

        Complexe c1 = new Complexe(2, 3);
        Complexe c2 = new Complexe(4,-6);
        Complexe product = new Complexe(c1.mult(c2).get_realpart(),c1.mult(c2).get_imagpart());
        System.out.println("Nombre Real :"+c1.get_realpart()+" "+"Nombre Imaginaire :"+c1.get_imagpart());
        System.out.println("Conjugé de nombre real et imaginaire : "+c1.conjugate());
        System.out.println("L'egalité des complexe : "+c1.equals(product));
        System.out.println(product);


    }
}
