package pfc.util;
import org.junit.*;
import static org.junit.Assert.*;
import pfc.Shape;
import pfc.util.Strategy;
import pfc.util.PaperStrategy;

public class PaperStrategyTest{

  @Test
  public void workingTest(){
    Strategy PaperStrat = new PaperStrategy();
    Shape hand = PaperStrat.getShape();
    assertSame(hand,Shape.PAPER);
    hand = PaperStrat.getShape();
    assertSame(hand,Shape.PAPER);
  }

  // ---For test execution----------------------
  public static junit.framework.Test suite() {
      return new junit.framework.JUnit4TestAdapter(PaperStrategyTest.class);
  }

}
