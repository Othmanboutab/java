package date;
import date.Date;

public enum Month {

 Janvier(31),Fevrier(28),Mars(31),Avril(30),Mai(31),Juin(30),Juillet(31),Aout(31),Septembre(30),Octobre(31),Novembre(30),Decembre(31);

 private final int nbDays;

 private Month(int nbDays) {
   this.nbDays=nbDays;
 }

/**
  * Returns the number of days in the year given.
  *
  * @param year a year
  * @return the number of days in the year given
  */
 public int nbDays(int year) {
   if (this !=Month.Fevrier || !Date.isBissextile(year)){
     return this.nbDays;
   }
   else {
     return this.nbDays +1;
   }
 }

/**
  * Returns the next month.
  *
  * @return the next month
  */
 public Month next() {
   return Month.values()[(this.ordinal()+1)%(Month.values().length)];
 }
}
