Rendu TP5_POO:
@author Mehdi BOUTAB
@author Othman BOUTAB
=====================

Groupe03 L2 informatique
===============================================

objéctifs du tp:
==================

* Organisation d'un projet Java.
* Ecriture des tests unitaires et les executer.
* Exécutaion d'un programme Java.
* Création d'une archive Java.

=================================================

* pour récuperer l'ensemble des fichiers du TP5, il faut d'abord se positionner dans le dossier BOUTAB-BOUTABO-POO
  ensuite ouvrir un terminal et taper la commade $ git pull

* pour génerer la documentation du paquetage example et de tous ses sous-paquetages, il faut se placer dans le fichier src et taper la 
  commande : $ javadoc factory factory.util -d ../docs

* pour compiler la classe Robot et ranger le résultat de la compilation dans le dossier classes il faut se placer dans tp5/src 
ensuite ouvrir un terminal et taper la commande :  $javac factory/Robot.java -d ../classes

* pour generer la documentation du packetage example et la placer dans le dossier docs il faut se placer dans le dossier tp5/src 
  ouvrir un terminal et taper la commande : $javadoc factory factory.util -d ../docs

 Tests :
=========
 
la classe Box:
--------------

* Pour tester les tests de la classe Box définis dans la classe de test BoxTest :
  il faut se placer dans le dossier tp5/src
  ensuite compiler la classe Box.java en tapant sur le terminal la commande :
  $ javac factory/util/Box.java -d ../classes
  ensuite il faut compiler la classe de test BoxTest.java en se plaçant à la racine du projet (tp5) et ouvrir un terminal et taper
  la commande : $ javac -classpath test4poo.jar test/BoxTest.java
  ensuite executer le test en tapant la commande : $ java -jar test4poo.jar BoxTest
  
  si la barre est verte çelà veut dire que les tests se sont bien passés.

la classe Robot:
----------------

* Pour tester les tests de la classe Robot définis dans la classe de test RobotTest :
  il faut se placer dans le dossier src du tp5
  ensuite compiler la classe Robot.java en tapant sur le terminal la commande :
  $ javac factory/Robot.java -d ../classes
  ensuite il faut compiler la classe de test RobotTest.java en se plaçant à la racine du projet et ouvrir un terminal et taper
  la commande : $ javac -classpath test4poo.jar test/RobotTest.java
  ensuite executer le test en tapant la commande : $ java -jar test4poo.jar RobotTest


la classe Date:
----------------

* Pour tester la classes DateMain :
  il faut se placer dans le dossier src du tp5/DATE/src
  ensuite compiler la classe DateMain en tapant sur le terminal la commande :
  $ javac date/DateMain.java
  ensuite pour tester la classe DateMain faut se poser sur le terminal et taper la commande :
  $ java date/DateMain
* pour la création d'archive il faut se placer dans le dossier date du tp5/DATE/src/date 
  ensuite taper sur le terminal la commande :
  $ jar cvf ../date.jar date
* pour l'utilisation de l'archive créée il faut se positionner dans le dossier DATE
  ensuite en tapant sur le terminal la commande : 
  $ java -classpath date.jar date.DateMain
* pour la creation d'un jar exécutable 
  il faut se position sur le terminal et taper la commande :
  $ jar cvfm ../date.jar manifest-date DATE
* pour l'exécution du programme 
  il faut se placer dans le dossier DATE du tp5/DATE
  ensuite taper sur le terminal la commande :
  $ java -jar date.jar

