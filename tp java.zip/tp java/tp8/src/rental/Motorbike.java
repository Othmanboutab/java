package rental;
import rental.*;

import java.util.*;
    
public class Motorbike extends Vehicle{
    private int cylindre;

    public Motorbike(String brand, String model, int productionYear, float dailyRentalPrice, int cylindre){
        super(brand, model, productionYear, dailyRentalPrice);
        this.cylindre=cylindre;
    }
    /**
     * @return the cylindre of Bike
     */
    public int getCylindre(){
        return this.cylindre;
    }
    public String toString(){
        return super.toString()+" "+this.cylindre;
    }
}
