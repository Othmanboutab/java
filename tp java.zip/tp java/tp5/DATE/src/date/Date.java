package date;
import date.Month;

public class Date {

 // attributs
 private int day;
 private Month month;
 private int year;

 // constructeur
/**
  * Creates a date with a day, a month and a year.
  *
  * @param d the day in the month
  * @param m the month
  * @param y the year
  */
 public Date(int d, Month m, int y) {
   this.day = d;
   this.month = m;
   this.year = y;
 }

 // méthodes
/**
  * Returns the day of the date.
  *
  * @return the day of the date
  */
 public int getDay() {
   return this.day;
 }

/**
  * Returns the month of the date.
  *
  * @return the month of the date
  */
 public Month getMonth() {
   return this.month;
 }

/**
  * Returns the year of the date.
  *
  * @return the year of the date
  */
 public int getYear() {
   return this.year;
 }

/**
  * Checks if two dates are equals.
  *
  * @param o the object to be compared to the date
  * @return <code>true</code> if the two dates are equals, <code>false</code> otherwise
  */
 public boolean equals(Object o) {
   if (o instanceof Date) {
     Date other = (Date) o;
     return (this.day==other.day) && (this.month==other.month) && (this.year==other.year);
   } else {
     return false;
   }
 }

/**
  * Returns the string of the date.
  *
  * @return the string of the date
  */
 public String toString() {
   return this.day + "/" + this.month + "/" + this.year;
 }

/**
  * Returns the date after the one given.
  *
  * @return the next day
  */
 public Date tomorrow() {
   if (this.day == this.month.nbDays(this.year)) {
     if (this.month == Month.Decembre) {
       return new Date(1, Month.Janvier, this.year+1);
     } else {
       return new  Date(1, this.month.next(), this.year);
     }
   } else {
     return new Date(this.day + 1, this.month, this.year);
   }
 }

/**
  * Returns <code>true</code> if the year is leap.
  *
  * @param year the year to test
  * @return <code>true</code> if the year is leap, <code>false</code> otherwise
  */
 public static boolean isBissextile(int year) {
   return (year%4==0 &&  (year%400!=0));
 }

/**
  * Returns the day n days later than the date given.
  *
  * @param nbDays the number of days
  * @return the day n days later than the date given
  */
 public Date nDaysLater(int nbDays) {
   if (nbDays<0) {
     throw new IllegalArgumentException("Argument should be positive");
   }
   Date result = this;
   for (int i=0; i<nbDays; i++) {
     result = result.tomorrow();
   }
   return result;
 }

/**
  * Returns the number of days separating two dates.
  *
  * @param d the date to be compared
  * @return the number of days separating two dates
  */
 public int diffDay(Date d) {
   if (this.compareTo(d)>0) {
     return -d.diffDay(this);
   }
   Date result = this;
   int cpt = 0;
   while (!result.equals(d)) {
     result = result.tomorrow();
     cpt++;
   }
   return cpt;
 }

/**
  * Returns 0 if the two dates are equals, -1 if the first date is previous of the second, 1 otherwise.
  *
  * @param d the date to be compared
  * @return 0 if the two dates are equals, -1 if the first date is previous of the second, 1 otherwise
  */
 public int compareTo(Date d) {
   if (this.equals(d)) {
     return 0;
   }
   if ((this.year < d.year) || ((this.year==d.year) && (this.month.ordinal() < d.month.ordinal()) || ((this.year==d.year) && (this.month.ordinal()==d.month.ordinal()) && (this.day < d.day)))) {
     return -1;
   } else {
     return 1;
   }
 }
}
