import org.junit.*;
import static org.junit.Assert.*;

import factory.Robot;   
import factory.util.*;   

public class RobotTest {	


    @Test
    public void robotCarryNoBoxWhenCreated() {
	Robot robbie = new Robot();
	assertFalse(robbie.carryBox());
    }

    @Test
    public void robotCanTakeBoxIfNotCarrying() {
        Robot robot= new Robot();
        assertEquals(false, robot.carryBox());
        Box box1= new Box(7);
        robot.take(box1);
        assertEquals(true, robot.carryBox());
    }
    @Test
    public void robotCannotTakeBoxIfAlreadyCarrying(){
        Robot robot = new Robot();
        assertFalse(robot.carryBox());
        Box box = new Box(3);
        robot.take(box);
        assertTrue(robot.carryBox());

    }
    @Test
    public void TestputOn(){
        Robot robot= new Robot();
        Box box1= new Box(5);
        Box box2= new Box(12);
        ConveyerBelt belt = new ConveyerBelt(10);
        ConveyerBelt belt2 = new ConveyerBelt(15);
        robot.take(box1);
        assertTrue(robot.carryBox());
        robot.putOn(belt);
        assertFalse(robot.carryBox());
        robot.take(box2);
        robot.putOn(belt2);
        assertFalse(robot.carryBox());
        robot.take(box1);
        robot.putOn(belt2);
        assertFalse(robot.carryBox());

    }



    
    // ---Pour permettre l'exécution des test----------------------
    public static junit.framework.Test suite() {
        return new junit.framework.JUnit4TestAdapter(RobotTest.class);
    }

}
