/**
 * A class for handling complex numbers.
 * @author Mehdi BOUTAB
 * @author Othman BOUTAB
 * @version 5/10/2020
 */
package com.company;
public class Complexe{
    // DEFINIR LES ATTRIBIUTS
    private float realpart;
    private float imagpart;

    /**
     * create a new object with the given real and imaginary parts
     * @param real
     * @param imaginary
     */
    public Complexe(float real,float imaginary){
        this.realpart=real;
        this.imagpart=imaginary;
    }

    /**
     * return realpart of the complex number
     * @return realpart
     */
    public float get_realpart(){
        return this.realpart;
    }

    /**
     * return imagpart of the complex number
     * @return imagpart
     */
    public float get_imagpart(){
        return this.imagpart;
    }

    /**
     * return a new Complex object whose value is the conjugate of this
     * @return complex congugate
     */
    public Complexe conjugate(){
        return new Complexe(this.realpart,-this.imagpart);
    }

    /**
     * return if the complex number is real
     * @return realpart
     */
    public boolean isreal(){
        return this.imagpart==0;
    }

    /**
     * return a new Complex object whose value is the complex module of this
     * @return
     */
    public double module(){
        double a= Math.sqrt(Math.pow(this.realpart,2));
        double b= Math.sqrt(Math.pow(this.imagpart,2));
        double ab=a+b;
        return Math.sqrt(ab);
    }

    /**
     * Method sum of two complex numbers.
     * @param c
     * @return sum of imagpart & realpart
     */
    public Complexe add(Complexe c){
        float realpart=this.realpart + c.get_realpart();
        float imagpart=this.imagpart + c.get_imagpart();
        return new Complexe(realpart,imagpart);

    }

    /**
     * The product of two complex numbers is a new complex object whose real and imaginary parts
     * @param c
     * @return product of imagpart & realpart
     */
    public Complexe mult(Complexe c){
        float realpart=(this.realpart+c.get_realpart())-(this.imagpart+c.get_imagpart());
        float imagpart=(this.imagpart+c.get_realpart()) + (this.realpart+c.get_imagpart());
        return new Complexe(realpart,imagpart);

    }

    /**
     * Method determining whether two complex numbers are equal.
     * @param o
     * @return true if the number are equal
     *         false otherwise
     */
    public boolean equals(Object o){
        if(o instanceof Complexe){
            Complexe c=(Complexe)o;
            return (this.realpart==c.get_realpart())&&(this.imagpart==c.get_imagpart());
        }
        return false;
    }

    /**
     *return a string represetation of this complex number
     * @return a string represatation of this rectangle using format
     *          "realpart"+'imagpart"+"i"
     */
    public String to_string(){
        return this.realpart+'+'+this.imagpart+"i";
    }

}

