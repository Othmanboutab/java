Rendu TP2_POO:

Author: Mehdi Boutab

Groupe03 L2 informatique 

======================================================
Présenation du tp:
=================
Le Tp contient  7 exercices  chaque exercice demande de créer une classeet manipuler des objets en appelant les différentes méthodes .

Lien du TP:
==========
https://www.fil.univ-lille1.fr/~routier/enseignement/licence/poo/tdtp/tp2.pdf


exercice 2:
==========
On va définir une classe pour modéliser des marchandises. Chaque marchandise (goods) est définie par un nom et unevaleur hors taxe en entier d’Euros


exercice 3:
==========
Création de classe light bulb .
il est possible de d'allumer light bulb , de l’éteindre, etc.Elle est définie par des propriétés :  la puissance (power) en Watt,  une couleur (pour simplifier il peut s’agir d’une chaine de caractères dans cet exercice), et le fait d’etre allumée ou éteint


exercice 4:
==========
On s’intéressera  ici à la modélisation  d’interrupteurs  (switch) électriques  qui  permettent  l’allumage  et  l’extinction d’une (et une seule) ampoule donnée.  L’ampoule controlée par l’interrupteur est définie à la construction de l’objet interrupteur.On peut appuyer sur un interrupteur  chaque  appui fait  passer  l’ampoule  de  éteinte à allumée  ouinversement.


Remarques:
==========

Pour tester:
============ 

>>>--ouvrir Blue J (projet >>> ouvrir un projet >>TP2>>>placez sur un dossier de classe voulou)

>>>--compiler la classe (clique droit sur l'icone de classe) 

>>>--créer une instance (clique droit sur la classe >>new classe)

>>>--clique droit sur l'instance affiché en bas gauche en rouge 

>>>--appelez la  fonction que vous voulez tester

Accés au code: 
==============
>>>--double clique sur l'icone de la classe.

Accés à la documentation: 
========================
>>>--il suffit juste de cliquer sur interface affiché en haut à droite ,après avoir cliquer sur l'incone de la classe.





=========================================================


