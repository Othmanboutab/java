package image;
import image.color.GrayColor;
public class Image  implements ImageInterface{
	//data fields attributes*
	private Pixel[][] pixels ;
	private int height;
	private int width ;
	private Pixel p = new Pixel(new GrayColor(255));
	/*Create an ImageResource object whose size is the width and height 
	 * passed as parameters and whose pixels are all white.
	 * @param width  the width of the image in pixels
	 * @param height the height of the image in pixels
	 * 
	 * 
	 */
	public Image(int height,int width) {
		pixels = new Pixel[this.height][this.width];
		for(int i = 0 ;i<this.width;i++) {
			for(int j=0;j<this.height;j++) {
				pixels[j][i]= p;
				}
		}

		
	}
	public int getWidth() {
		
		return this.width;
	}
	
	public int getHeight() {
		
		return this.height;
	}
	
	public Pixel getPixel(int x, int y)  {
		return this.pixels[y][x];	//j'ai inversé les x et y sinon ça marche pas 
	
	}
	
	public void changeColorPixel(int x, int y, GrayColor color)  throws UnknownPixelException   {
		if( x >= this.pixels[0].length || y >= this.pixels.length) {
			throw new UnknownPixelException("this pixel does not exist ");
		}
		else {
			this.pixels[y][x].setColor(color);
		}
	
		}
    /**
     * draw in this image a rectangle with the given width and height, 
     * "fully" colored with "color"; 
     * the coord of the top left corner of that rectangle is (x, y)
     * @param x horizontal coord of the to left corner of the drawed rectangle
     * @param y vertical coord of the to left corner of the drawed rectangle
     * @param width width of the drawed rectangle
     * @param height height of the drawed rectangle
     * @param color color used to fill the drawed rectangle
     */
    public void fillRectangle(int x, int y, int width, int height, GrayColor color){
        int xLimit = Math.min(x + width - 1, this.getWidth() - 1);
        int yLimit = Math.min(y + height - 1, this.getHeight() - 1);
        int initY = y;
        while(x <= xLimit){
            y = initY;
            while(y <= yLimit){
                this.getPixel(x, y).setColor(color);
                y++;
            }
            x++;
        }
    }
							
	


	  /**
     * return a new image by extracting the edges of this image
     * @param threshold threshold used for the edges'extraction
     * @return a new image by extracting the edges of this image
     */
	
	public Image edges(int threshold) {
		// Create a new image into which the resulting pixels will be stored.
		Image result = new Image(this.height,this.width);
		//Nested loop over each pixel
		for(int x = 0; x<this.width - 1 ;x++) {
			for(int y = 0;y<this.height - 1 ;y++) {  // j'ai suprrimé quelques lignes qui ne sevraient à rien 
				if (this.getPixel(x,y).colorLevelDifference(this.getPixel(x+1,y)) > threshold ||  this.getPixel(x,y).colorLevelDifference(this.getPixel(x,y+1)) > threshold){
					 result.getPixel(x, y).setColor(GrayColor.BLACK);
				}
			}
		}
		return result;
	}
	
		
		
	
	public Image decreaseNbGrayLevels(int nbGrayLevels) {
		Image decreaseImage = new Image(this.height,this.width);
		//Nested loop over each pixel
		for(int y = 0; y < this.height; y++){
            for(int x =0; x < this.width; x++){
                int GrayLevel = this.getPixel(x,y).getColor().getGrayLevel();
                int newGrayLevel = GrayLevel-(GrayLevel%(256/nbGrayLevels));
                decreaseImage.changeColorPixel(x,y, new GrayColor(newGrayLevel));
            }
		}
		return decreaseImage;
    
	
			
}
	public void setPixel(int i, int j, Pixel pixel) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void fillRect(int x, int y, int width, int height, GrayColor color) {
		// TODO Auto-generated method stub
		
	}
	public static Image initImagePGM(String fileName) {
		// TODO Auto-generated method stub
		return null;
	}


		
		
	
	
	
	
	
	
		
	
		
		
		
		
		
		
	
		
	
		
		
		
	
		
	
		
		
	
		
		
		
	
		
	
	
	
		
		
		
	
	
	

}
