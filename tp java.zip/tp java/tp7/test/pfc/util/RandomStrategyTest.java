package pfc.util;
import org.junit.*;
import static org.junit.Assert.*;
import pfc.Shape;
import pfc.util.Strategy;
import pfc.util.RandomStrategy;

public class RandomStrategyTest{

  @Test
  public void workingTest(){
    Strategy randomStrat = new RandomStrategy();
    Shape hand = randomStrat.getShape();
    assertTrue(Shape.contains(hand.toString()));
  }

  // ---For test execution----------------------
  public static junit.framework.Test suite() {
      return new junit.framework.JUnit4TestAdapter(RandomStrategyTest.class);
  }

}
