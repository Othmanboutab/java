TP6
#Auteurs :Mehdi BOUTAB && Othman BOUTAB
#Groupe 3A

# TP et objectifs
le tp consiste à:
  * manipuler des images



# Generer la documentation
  afin de generer la documentation il faut via le terminal se placer dans le dossier src et efectuer la commande suivante :
	$ javadoc -d ../docs -subpackages *
    le documentation est alors generée dans le dossier docs et il suffit de l'ouvrir avec un navigateur internet pour la consulter



# Compiler et executer les classes du projet
  * Compiler :
    afin de compiler une classe il faut via le terminal se placer dans le repertoire src et effectuer la commande suivante
      - $ javac ThisClass.java -d ../classes
      (il faut remplacer ThisClass par le nom de la classe à compliler)
      Ceci creera un fichier .class pour cette classe.

  * executer :
    afin d'executer une classe il faut via le terminal se placer dans le repertoire classes et effectuer la commande :
    $ java ThisClass
    (il faut remplacer ThisClass par le nom de la classe à executer)

 * example:
	pour compiler ImageExample:
		$ javac image/ImageExample.java -d ../classes
	pour compiler ImageMain:
		$ javac image/ImageMain.java -d ../classes
	pour compiler GrayColor:
		$ javac image/color/GrayColor.java -d ../classes


# Generer les tests

  * afin de generer les tests il faut via le terminal se placer à la racine du projet et efectuer la commande suivante :
            - $ javac -classpath test-1.7.jar test/SomeClassTest.java
		(afin de compiler le test, en remplacant SomeClass par la classe voulue)

    * une fois les fichiers compilés il faut les executer via le terminal avec la commande:
            - $ java -jar test-1.7.jar SomeClassTest
		(en remplacant SomeClass par la classe voulue)

   * example pour:

	 compiler ImageTest:
		 - $ javac -classpath test-1.7.jar test/ImageTest.java
		  puis pour executer le test:
		 - $ java -jar test-1.7.jar ImageTest
	
	st





# executer le programme:
	- Executer imageMain
		- avec le jar:
			generer le jar:
				se placer dans le dossier classes et executer avec la commande:
						jar cvf ../image.jar image
				puis ajouter le manifest avec la commande :
						jar cvfm ../image.jar ../manifest-ex image ../images

						
			executer le jar:
				se placer a la racine du projet et executer la commande suivante via le terminal:
				java -jar image.jar (avec en parametre :  -le nom de l'image sous la forme: /images/fruit.pgm avec en remplacant fruit.pgm pour le nom de l'image
									  - le seuil d’extraction de contours
									  - le nombre de niveaux de gris)


										

		-avec le fichier class
			se placer dans le dossier classes
			$ java image.ImageMain

	- Executer imageMain
		- avec le jar:
			generer le jar:
				se placer dans le dossier classes et executer avec la commande:
						jar cvf ../example.jar image
				puis ajouter le manifest avec la commande :
						jar cvfm ../example.jar ../manifest-ex2 image
			executer le jar:
				se placer a la racine du projet et executer la commande suivante via le terminal:
				java -jar example.jar
			

		-avec le fichier class
			$ java image.ImageExample

