package pfc.util;
import org.junit.*;
import static org.junit.Assert.*;
import pfc.Shape;
import pfc.util.Strategy;
import pfc.util.RockPaperStrategy;

public class RockPaperStrategyTest{

  @Test
  public void workingTest(){
    Strategy RPStrat = new RockPaperStrategy();
    Shape hand = RPStrat.getShape();
    assertSame(hand,Shape.ROCK);
    hand = RPStrat.getShape();
    assertSame(hand,Shape.PAPER);
    hand = RPStrat.getShape();
    assertSame(hand,Shape.ROCK);
  }

  // ---For test execution----------------------
  public static junit.framework.Test suite() {
      return new junit.framework.JUnit4TestAdapter(RockPaperStrategyTest.class);
  }

}
