package rental;
import rental.*;

import java.util.*;

public class Car extends Vehicle{
    private int capacity;

    public Car(String brand, String model, int productionYear, float dailyRentalPrice, int capacity){
        super(brand, model, productionYear, dailyRentalPrice);
        this.capacity=capacity;
    }
    /**
     * @return the capacity of car 
     */
    public int getCapacity(){
        return this.capacity;
    }

    public String toString(){
        
        return super.toString()+" "+this.capacity;
    }

}