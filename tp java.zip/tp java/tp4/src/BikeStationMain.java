public class BikeStationMain{

  public static void main(String[] args) {

    BikeStation station_timo = new BikeStation("Timoleon", 10);
    Bike b1 = new Bike("b001", BikeModel.CLASSICAL);
    Bike b2 = new Bike("b002", BikeModel.ELECTRIC);
    station_timo.dropBike(b1);
    station_timo.dropBike(b2);
    int i = 0;
    if (args.length ==1){
      i = Integer.parseInt(args[0]);
    }
    if (station_timo.takeBike(i) != null){
      Bike description = station_timo.takeBike(i);
      System.out.println(description);
    }
    else{
      String tmp = " There is no bike on the place "+i;
      System.out.println(tmp);

    }
    System.out.println(args.length);
  }

}
